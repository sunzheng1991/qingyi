<?php

return array (
	'default' => array (
		'hostname' => '121.42.50.192',
		'database' => 'qingyi',
		'username' => 'root',
		'password' => 'gyq2989482!',
		'tablepre' => 'v9_',
		'charset' => 'utf8',
		'type' => 'mysql',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
);

?>