<?php
/**
 * 积分兑换配置
 */
return array(
				1 => array('点数', '点'),
				2 => array('金币', '金'),
			);

?>