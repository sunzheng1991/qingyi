<?php
return array (
  'special' => '52',
);
?>