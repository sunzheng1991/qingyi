<?php
return array (
  1 => 
  array (
    'typeid' => '1',
    'name' => '新闻',
    'sort' => '1',
  ),
  3 => 
  array (
    'typeid' => '3',
    'name' => '图片',
    'sort' => '2',
  ),
  2 => 
  array (
    'typeid' => '2',
    'name' => '下载',
    'sort' => '3',
  ),
  'special' => 
  array (
    'typeid' => '52',
    'name' => '专题',
  ),
);
?>