<?php
return array (
  7 => '1',
);
?>