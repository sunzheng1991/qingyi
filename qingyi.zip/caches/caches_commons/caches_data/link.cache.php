<?php
return array (
  1 => 
  array (
    'is_post' => '1',
    'enablecheckcode' => '0',
  ),
);
?>