<?php
$LANG['send_message'] = '发送短消息';
$LANG['all_send_message'] = '群发短消息';
$LANG['message'] = '短消息';
$LANG['send'] 	= 	'发送';
$LANG['sendto'] 	= 	'发送到';
$LANG['subject'] 	= 	'标题';
$LANG['content'] 	= 	'内容';
$LANG['setting'] 	= 	'配置';
$LANG['touserid'] 	= 	'收件人';
$LANG['fromuserid'] 	= 	'发件人';
$LANG['send_time'] 	= 	'发信时间';
$LANG['reply'] 	= 	'回复';
$LANG['is_reply'] 	= 	'是否回复';
$LANG['remove_all_selected'] 		= 	'删除选中';
$LANG['user_noempty']				= 	'收件人不能为空';
$LANG['username']					= 	'用户名';
$LANG['time']						= 	'时 间';
$LANG['see_info']					= 	'查看详情';
$LANG['no_empty']					= 	'不能为空';
$LANG['before_select_operation']	=	'请选择再执行操作'; 

$LANG['no_thisuser']				=	'没有此用户'; 
$LANG['connecting']					=	'正在连接，请稍候。'; 

$LANG['group']						=	'按会员组'; 
$LANG['role']						=	'按角色'; 
$LANG['send_num']					=	'每轮发送次数'; 

$LANG['select']['send_from_id']		= 	'发件人';
$LANG['select']['send_to_id'] 		= 	'收件人';
$LANG['not_myself']					=	'禁止给自己或非注册用户发送消息'; 
$LANG['sendtime']					=	'发送时间';
$LANG['show_m']						=	'显示';
$LANG['details']					=	'查看详情';
$LANG['message_sender']				=	'发 信 人';
$LANG['query_type']					=	'查询类型';
$LANG['to']							=	'至';
$LANG['message_not_exist']			=	'短消息不存在';
$LANG['mass_failure']				=	'群发失败,请检查！';
?>