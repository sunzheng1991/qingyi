<?php
$LANG['member_init'] = 'Administration';
$LANG['account_manage'] = 'Account Manager';
$LANG['favorite'] = 'Favorite';
$LANG['123'] = '123';
$LANG['pay'] = 'Online payment';
?>